let taskList = document.getElementById("taskList");

function addTask() {
    let taskInput = document.getElementById("taskInput");
    let taskText = taskInput.value.trim();

    if (taskText !== "") {
        let taskItem = document.createElement("li");
        taskItem.innerText = taskText;

        // Add ability to mark task as completed
        taskItem.addEventListener("click", function() {
            taskItem.classList.toggle("completed");
        });

        taskList.appendChild(taskItem);
        taskInput.value = "";
    }
}
